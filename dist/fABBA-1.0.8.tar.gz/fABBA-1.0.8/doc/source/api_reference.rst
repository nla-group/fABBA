API Reference
======================================

.. autofunction:: fABBA.symbolic_representation

