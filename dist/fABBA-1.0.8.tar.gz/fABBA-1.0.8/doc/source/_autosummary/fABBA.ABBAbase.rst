﻿fABBA.ABBAbase
==============

.. currentmodule:: fABBA

.. autoclass:: ABBAbase

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ABBAbase.__init__
      ~ABBAbase.compress
      ~ABBAbase.digitize
      ~ABBAbase.fit_transform
      ~ABBAbase.inverse_transform
      ~ABBAbase.reassign_labels
   
   

   
   
   