﻿fABBA.ABBA
==========

.. currentmodule:: fABBA

.. autoclass:: ABBA

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ABBA.__init__
      ~ABBA.compress
      ~ABBA.digitize
      ~ABBA.fit_transform
      ~ABBA.inverse_transform
      ~ABBA.reassign_labels
   
   

   
   
   