﻿fABBA.fabba\_model
==================

.. currentmodule:: fABBA

.. autoclass:: fabba_model

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~fabba_model.__init__
      ~fabba_model.aggregate
      ~fabba_model.compress
      ~fabba_model.digitize
      ~fabba_model.dump
      ~fabba_model.fit_transform
      ~fabba_model.inverse_transform
      ~fabba_model.load
      ~fabba_model.print_parameters
      ~fabba_model.reassign_labels
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~fabba_model.alpha
      ~fabba_model.max_len
      ~fabba_model.n_jobs
      ~fabba_model.return_list
      ~fabba_model.scl
      ~fabba_model.sorting
      ~fabba_model.tol
      ~fabba_model.verbose
   
   