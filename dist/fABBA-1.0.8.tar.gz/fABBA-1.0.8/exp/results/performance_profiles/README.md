This folder stores results about performance profiles against SAX, 1d-SAX, and ABBA. 
it also contains experimental results of alpha = 0.1, 0.3, 0.5. The folder denoted by "fig" is the 
fABBA time series reconstruction against SAX, 1d-SAX and ABBA.