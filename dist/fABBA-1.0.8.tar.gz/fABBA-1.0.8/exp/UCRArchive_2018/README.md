Download from https://www.cs.ucr.edu/~eamonn/time_series_data_2018/
