
Download from http://cs.joensuu.fi/sipu/datasets/
